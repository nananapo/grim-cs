public enum PrimitiveFunctionType
{
    Assign,
    Put,
    Input
}