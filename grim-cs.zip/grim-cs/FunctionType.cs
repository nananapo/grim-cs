public enum FunctionType
{
    General,
    Prefix,
    Mid,
    Suffix
}