public abstract class ExpressionToken
{
}